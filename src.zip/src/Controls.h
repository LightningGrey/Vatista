#pragma once

enum class Controls{
	LEFT,
	RIGHT,
	UP,
	DOWN,
	X,
	Y
};